﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MLearning.Core.Classes
{
    class PassBytes
    {
        List<Guid> CollectionGuid { get; set; }
    }
}
