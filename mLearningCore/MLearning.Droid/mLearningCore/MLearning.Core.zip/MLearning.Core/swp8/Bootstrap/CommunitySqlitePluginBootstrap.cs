using Cirrious.CrossCore.Plugins;

namespace MLearning.Core.Bootstrap
{
    public class SqlitePluginBootstrap
        : MvxPluginBootstrapAction<Cirrious.MvvmCross.Community.Plugins.Sqlite.PluginLoader>
    {
    }
}